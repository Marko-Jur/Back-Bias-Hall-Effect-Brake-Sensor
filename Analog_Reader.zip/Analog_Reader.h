#ifndef ANALOG_READER_H   
#define ANALOG_READER_H

void analogReaderSetup();
void analogReader(int control_array[2]);

#endif
