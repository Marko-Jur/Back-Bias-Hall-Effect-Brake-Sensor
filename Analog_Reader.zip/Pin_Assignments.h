#ifndef PIN_ASSIGNMENTS_H   
#define PIN_ASSIGNMENTS_H

//Globals:
const float EMA_ALPHA = 0.6;

#define TOGGLE_SWITCH 19
#define POT A5
#define BRAKE_SENSOR A7

//LCD pins
//#define


//Servo pin
#define BRAKE_SERVO 3




#endif
