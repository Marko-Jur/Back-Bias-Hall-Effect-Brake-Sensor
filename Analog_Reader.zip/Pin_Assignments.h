#ifndef PIN_ASSIGNMENTS_H   
#define PIN_ASSIGNMENTS_H

//Globals:
const float EMA_ALPHA = 0.6;

#define TOGGLE_SWITCH 19
#define POT 20
#define BRAKE_SENSOR 26

//LCD pins
//#define


//Servo pin
//#define




#endif
