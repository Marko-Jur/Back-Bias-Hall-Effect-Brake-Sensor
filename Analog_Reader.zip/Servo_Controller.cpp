#include "Libraries.h"
#include "Pin_Assignments.h"
#include "Analog_Reader.h"
#include "LCD_Controller.h"
#include "Servo_Controller.h"

#import <Arduino.h>

Servo brake_servo;


void servoSetup(){

  brake_servo.attach(BRAKE_SERVO);

  
}

void servoControl(int control_array[2]){

  brake_servo.write(0);
  delay(5000);
  brake_servo.write(70);
  delay(5000);

  
}
