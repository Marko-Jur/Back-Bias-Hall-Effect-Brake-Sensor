#ifndef LCD_CONTROLLER_H   
#define LCD_CONTROLLER_H

void LCDSetup();
void LCDDisplay(int control_array);

#endif
