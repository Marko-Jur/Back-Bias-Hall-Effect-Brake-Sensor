#ifndef SERVO_CONTROLLER_H   
#define SERVO_CONTROLLER_H

void servoSetup();
void servoControl(int control_array);

#endif
