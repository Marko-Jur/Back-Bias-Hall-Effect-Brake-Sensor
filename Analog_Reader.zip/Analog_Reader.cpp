#include "Libraries.h"
#include "Pin_Assignments.h"
#include "Analog_Reader.h"
#include "LCD_Controller.h"
#include "Servo_Controller.h"

#import <Arduino.h>

float voltage = 0.00;
float EMA_PREVIOUS = 0.00;


void analogReaderSetup(){

  pinMode(TOGGLE_SWITCH, INPUT);
  pinMode(POT, INPUT);
  
  EMA_PREVIOUS = analogRead(BRAKE_SENSOR);
  
}

void analogReader(int control_array[2]){

  voltage = analogRead(BRAKE_SENSOR);
  voltage = (EMA_ALPHA*voltage)+(EMA_PREVIOUS*(1-EMA_ALPHA));
  Serial.println(voltage);

  
}
