#include "Libraries.h"
#include "Pin_Assignments.h"
#include "Analog_Reader.h"
#include "LCD_Controller.h"
#include "Servo_Controller.h"

#import <Arduino.h>

float voltage = 0.00;
float pot_val = 0.00;
float EMA_PREVIOUS_BRAKE = 0.00;
float EMA_PREVIOUS_POT = 0.00;


void analogReaderSetup(){

  pinMode(TOGGLE_SWITCH, INPUT);
  pinMode(POT, INPUT);
  
  EMA_PREVIOUS_BRAKE = analogRead(BRAKE_SENSOR);
  EMA_PREVIOUS_POT = analogRead(BRAKE_SENSOR);
  
}

void analogReader(int control_array[2]){

  voltage = analogRead(BRAKE_SENSOR);
  voltage = (EMA_ALPHA*voltage)+(EMA_PREVIOUS_BRAKE*(1-EMA_ALPHA));

  if (voltage > 700){
    Serial.println("Engaged");
  }
  else{
    Serial.println("No brake");
  }

  pot_val = analogRead(POT);
  pot_val = (EMA_ALPHA*pot_val)+(EMA_PREVIOUS_POT*(1-EMA_ALPHA));
  

  
}
