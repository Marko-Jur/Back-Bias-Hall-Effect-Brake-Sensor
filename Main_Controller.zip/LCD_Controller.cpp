#include "Libraries.h"
#include "Pin_Assignments.h"
#include "Analog_Reader.h"
#include "LCD_Controller.h"
#include "Servo_Controller.h"

#import <Arduino.h>


void LCDSetup(){

  
}



void LCDDisplay(int control_array){
  
}
